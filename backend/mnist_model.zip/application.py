from flask import Flask, request, jsonify
import tensorflow as tf
from PIL import Image
import io
import base64
from flask_cors import CORS
import numpy as np

application = Flask(__name__)


CORS(application, resources={r"/predict/*": {"origins": "http://digit-classification-frontend.s3-website.us-east-2.amazonaws.com", "methods": "POST", "allow_headers": "Content-Type"}})

# Load the trained model
model = tf.keras.models.load_model('mnist_model.h5')

@application.route('/predict', methods=['POST'])
def predict():
    image_data = request.json['image']
    decoded_image = base64.b64decode(image_data.split(',')[1])
    image = Image.open(io.BytesIO(decoded_image)).convert('L').resize((28, 28))
    image_array = np.array(image) / 255.0
    prediction = model.predict(image_array.reshape(1, 28, 28, 1)).argmax()
    return jsonify({"prediction": str(prediction)})

@application.route('/test', methods=['GET'])
def test():
    return "Concluded"
if __name__ == '__main__':
    application.run(debug=True)
